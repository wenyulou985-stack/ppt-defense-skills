先读 PREINSTALL.md，再读取 skills 下对应技能。
本包为普通三套 Skills；Muse 补充包见仓库 MUSE.md。
