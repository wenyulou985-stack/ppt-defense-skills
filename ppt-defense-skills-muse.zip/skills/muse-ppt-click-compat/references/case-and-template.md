# Muse 案例与候选 timing 片段

以下是用户提交复盘的摘录与整理，未在本次发布中重新播放验证。缺少原 PPTX、录像及完整播放器版本，不能作为通用兼容性保证。

## 记录中的失败模式

- v1：整页栅格化，无法独立控制内部内容；多页展开不符合本用户单页点击要求。
- v2：报告提到 timing 被放入 cSld、触发条件与主序列混用、空效果体、隐藏状态未恢复、目标放错层级、build 信息缺失。
- v4：结构检查和样本对照通过，报告的 WPS 本机放映仍失败；另外用户检查曾使用普通视图。两类证据要分开，不能把全部失败都归于用户操作或某一个 XML 属性。
- v5：报告称组合变体 E 在 WPS Linux 实播成功。没有隔离哪个属性起作用；未记录精确版本。复盘只明确记载了第2页的整稿抽查，不应说全稿各页均已验证。

## 候选片段：按记录原样保留

这只是一个点击步骤片段，不是完整、可直接运行的模板。省略的时间节点 ID 必须替换为页内唯一值，N 必须替换为实际形状 ID，外层主序列、命名空间等需由生成器补齐并验证。先在最小试验上测试，不能不经实播批量套用。

```xml
<p:par>
  <p:cTn id="…" fill="hold">
    <p:stCondLst><p:cond delay="indefinite"/></p:stCondLst>
    <p:childTnLst>
      <p:par>
        <p:cTn id="…" fill="hold">
          <p:stCondLst><p:cond delay="0"/></p:stCondLst>
          <p:childTnLst>
            <p:par>
              <p:cTn id="…" fill="hold" grpId="0" nodeType="clickEffect"
                     presetID="1" presetClass="entr" presetSubtype="0">
                <p:stCondLst><p:cond delay="0"/></p:stCondLst>
                <p:childTnLst>
                  <p:set>
                    <p:cBhvr>
                      <p:cTn id="…" dur="1" fill="hold">
                        <p:stCondLst><p:cond delay="0"/></p:stCondLst>
                      </p:cTn>
                      <p:tgtEl><p:spTgt spid="N"/></p:tgtEl>
                      <p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst>
                    </p:cBhvr>
                    <p:to><p:strVal val="visible"/></p:to>
                  </p:set>
                  <p:animEffect transition="in" filter="appear">
                    <p:cBhvr>
                      <p:cTn id="…" dur="500"/>
                      <p:tgtEl><p:spTgt spid="N"/></p:tgtEl>
                    </p:cBhvr>
                  </p:animEffect>
                </p:childTnLst>
              </p:cTn>
            </p:par>
          </p:childTnLst>
        </p:cTn>
      </p:par>
    </p:childTnLst>
  </p:cTn>
</p:par>
```

原报告认为 set(visible) 与 animEffect(in, appear) 的组合值得优先试验，并建议核对 seq 的前后推进条件和 build 列表。这里保留为案例线索；不能据此说纯 set 在所有播放器都无效、evt=onClick 在所有场景都错误、所有对象都必须用同一种 bldP，或任一引用错误必然导致整页失效。

## 可复核记录模板

文件名 / SHA256：
操作系统 / 播放器 / 版本：
幻灯片编号 / 预计点击序列：
实际放映入口 / 推进操作：
S0、S1、S2、S3 截图或录像时间点：
对象区域和页身份观察：
结果：通过 / 失败 / 未验证
未测范围与限制：
