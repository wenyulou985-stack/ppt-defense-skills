先读 PREINSTALL.md，再读取 skills 下对应技能。
本包包含原三套 Skills 及 Muse 补充层。
